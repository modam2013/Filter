package ru.hogwarts.school.exception;

public class AvatarProcessingException extends RuntimeException {

}
